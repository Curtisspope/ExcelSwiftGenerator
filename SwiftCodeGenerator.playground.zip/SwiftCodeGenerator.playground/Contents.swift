//: Swift Code Generator PlayGround

import UIKit

//This is code generated from the excel file provided.


class Car :NSObject{

    var make : String?
    var model : String?
    var color : UIColor?
    var category : String?
    var mileage : Int?
    var id : Int?

    override init() {
        
        
    }
    
    
    func new(make:String,model:String,color:UIColor,category:String,mileage:Int,id:Int){
        
        self.make=make
        self.model=model
        self.color=color
        self.category=category
        self.mileage=mileage
        self.id = id
    
    
    
    }
  
}




var c:Car = Car()

c.new(make: "Honda", model: "Civic", color: UIColor.blue, category: "Sedan", mileage: 20000, id: 1)


print(c.category!)





enum Models:String{
    case Honda
    case Mercury
}






